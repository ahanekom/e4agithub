Oracle JDBC Drivers
repackaged for STANDALONE installation by Oracle Applications

Source of this README file: jdbc14.zip (rehosted in Apps from 
ojdbc14.jar 9.2.0.6 + MLR 4253129 + fix 4128146 + fix 4191890 

Content Description:
  Oracle JDBC Thin Drivers for JDK 1.4
  Version 9.2.0.6  

Java namespace(s) included:
  oracle/sql
  oracle/jdbc
  oracle/jpub
  oracle/core
  oracle/gss
  oracle/net
  oracle/security

This archive file contains Java classes and resource files that have been
repackaged for easy delivery and patching to Oracle Applications customers.
If you are viewing this README from an archive or directory other than the
source listed above, please note that this README applies only to files that
are within the above listed namespace(s).
